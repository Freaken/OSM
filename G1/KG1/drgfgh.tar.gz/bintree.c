#include <stdlib.h>
#include <stdio.h>
#include "bintree.h"

void print_node(tnode_t *node) {
    printf("adress: %p value: %d lchild: %p rchild: %p \n", (void *) node, node->data,(void *) node->lchild, (void *) node->rchild);

    if(node->lchild != NULL) {
        print_node(node->lchild);
    }

    if(node->rchild != NULL) {
        print_node(node->rchild);
    }
}

int main() {
    tnode_t *tree;
    insert(&tree, 3);
    insert(&tree, 8);
    insert(&tree, 2);
    insert(&tree, 7);

    //print_node(tree);
    //print_inorder(tree);
    //printf("\n");
    //printf("%d\n",size(tree));
    //int *array = to_array(tree);
    int i = 5;
    /*
    printf("jeg læser fra %p: %d \n", array, *array);
    printf("jeg læser fra %p: %d \n", array+1, *(array+1));
    printf("jeg læser fra %p: %d \n", array+2, *(array+2));
    printf("jeg læser fra %p: %d \n", array+3, *(array+3));
    for (i = 0; i < 4; i++) {
        printf("jeg læser fra %p: %d \n", array+i, *(array+i));
    } */
    return 0;
}

void insert(tnode_t **tree, int value) {
    if(*tree == NULL) {

        //Allocate memory for the node
        *tree = malloc(sizeof(tnode_t));
        if(tree == NULL) {
            printf("malloc failed\n");
            exit(1);
        }

        //Initialize node
        (*tree)->data = value;
        (*tree)->lchild = NULL;
        (*tree)->rchild = NULL;
    }

    else {
        //Traverse the tree to find an empty node at correct place
        if(value <= (*tree)->data) {
            insert(&(*tree)->lchild, value);
        }
        else {
            insert(&(*tree)->rchild, value);
        }
    }
}

void print_inorder(tnode_t* tree) {
    //print left part of tree
    if(tree->lchild != NULL) {
        print_inorder(tree->lchild);
    }

    //print value of current node
    printf("%d ", tree->data);

    //print right part of tree
    if(tree->rchild != NULL) {
        print_inorder(tree->rchild);
    }
}

int size(tnode_t *tree) {
    //Tree is empty
    if(tree == NULL) {
        return 0;
    }

    //Recursively find the size
    return 1 + size(tree->lchild) + size(tree->rchild);
}

void node_value(tnode_t *tree, int **pos) {
    if(tree->lchild != NULL) {
        node_value(tree->lchild, pos);
    }

    **pos = tree->data;
    printf("jeg skriver %d til %p\n", tree->data, *pos);
    (*pos)++;

    if(tree->rchild != NULL) {
        node_value(tree->rchild, pos);
    }
}

int* to_array(tnode_t *tree) {
    //Allocate memory for the array
    int length = size(tree);
    int *array = malloc(sizeof(int)*length);
    printf("%p %d\n", array, sizeof(int));
    if(array == NULL) {
        printf("malloc failed");
        exit(1);
    }
    int *pos = array;

    node_value(tree, &pos);

    return array;
}
